 <?php
/*
Plugin Name: project test
Description: product project plugin
*/

add_action( 'plugins_loaded', array( 'WC_Frontnend_Shop_Manager_Free', 'init' ));

class WC_Frontnend_Shop_Manager_Free {

	public static $path;
	public static $url_path;
	public static $settings;

	public static function init() {
		$class = __CLASS__;
		new $class;
	}

	function __construct() {

		if ( !class_exists('pt') || !current_user_can('edit_products') ) {
			return;
		}

		self::$path = plugin_dir_path( __FILE__ );
		self::$url_path = plugins_url( __FILE__ );

		self::$settings['user'] = wp_get_current_user();
		self::$settings['pt']['decimal_sep'] = get_option( 'pt_price_decimal_sep' );

		if ( self::$settings['user']->has_cap( 'administrator' ) || self::$settings['user']->has_cap( 'manage_pt' ) ) {
			self::$settings['admin_mode'] = true;
		}

		add_action( 'init', array(&$this, 'ptpsm_textdomain') );
		add_action( 'wp_enqueue_scripts', array(&$this, 'ptpsm_scripts') );

		add_action( 'pt_before_shop_loop_item', array(&$this, 'ptpsm_content') );
		add_action( 'pt_before_single_product_summary', array(&$this, 'ptpsm_content'), 5 );
		add_action( 'wp_ajax_ptpsm_respond', array(&$this, 'ptpsm_respond') );
		add_action( 'wp_ajax_ptpsm_save', array(&$this, 'ptpsm_save') );

	}

	public static function ptpsm_get_path() {
		return plugin_dir_path( __FILE__ );
	}

	function ptpsm_textdomain() {
		$dir = trailingslashit( WP_LANG_DIR );
		load_plugin_textdomain( 'ptpsm', false, $dir . 'plugins' );
	}

	function ptpsm_scripts() {
		wp_enqueue_style( 'ptpsm-selectize', plugins_url( 'assets/css/selectize.default.css', __FILE__) );
		wp_enqueue_style( 'ptpsm-style', plugins_url( 'assets/css/styles.css', __FILE__) );

		wp_register_script( 'ptpsm-selectize', plugins_url( 'assets/js/selectize.min.js', __FILE__), array( 'jquery' ), '1.0.0', true );
		wp_register_script( 'ptpsm-scripts', plugins_url( 'assets/js/scripts.js', __FILE__), array( 'jquery' ), '1.0.0', true );
		wp_register_script( 'ptpsm-init', plugins_url( 'assets/js/scripts-init.js', __FILE__), array( 'jquery' ), '1.0.0', false );
		wp_enqueue_media();
		wp_enqueue_script( array( 'ptpsm-init', 'jquery-ui-datepicker', 'ptpsm-selectize', 'ptpsm-scripts' ) );
		$curr_args = array(
			'ajax' => admin_url( 'admin-ajax.php' )
		);

		wp_localize_script( 'ptpsm-scripts', 'ptpsm', $curr_args );
	}


	function ptpsm_content() {

		global $post, $pt_loop;

		$curr_id = $post->ID;

		if ( !isset( self::$settings['admin_mode'] ) && absint( $post->post_author ) !== self::$settings['user']->ID ) {
			return;
		}

		$add_loop = ( ( isset( $pt_loop['columns'] ) && empty( $pt_loop['columns'] ) ) || !isset( $pt_loop['columns'] ) || !isset( $pt_loop['loop'] ) ? 'single' : $pt_loop['loop'] . '|' . $pt_loop['columns'] );

	?>
		<div class="ptpsm-buttons" data-id="<?php echo $curr_id; ?>" data-loop="<?php echo $add_loop; ?>">
			<a href="#" class="ptpsm-button ptpsm-activate" title="<?php _e( 'Quick edit product', 'ptpsm' ); ?>"><i class="ptpsmico-activate"></i></a>
			<a href="<?php echo esc_url( admin_url( 'post.php?post=' . absint( $curr_id ) . '&action=edit' ) ); ?>" class="ptpsm-button ptpsm-edit" title="<?php _e( 'Edit product in the backend', 'ptpsm' ); ?>"><i class="ptpsmico-edit"></i></a>
			<a href="#" class="ptpsm-button ptpsm-save" title="<?php _e( 'Save changes', 'ptpsm' ); ?>"><i class="ptpsmico-save"></i></a>
			<a href="#" class="ptpsm-button ptpsm-discard" title="<?php _e( 'Discard changes', 'ptpsm' ); ?>"><i class="ptpsmico-discard"></i></a>
			<span class="ptpsm-editing">
				<img width="64" height="64" src="<?php echo plugins_url( 'assets/images/editing.png', __FILE__ ); ?>" />
				<small>
					<?php _e( 'Currently Editing', 'ptpsm' ) ; ?><br/>
					<?php _e( 'Tap to Save', 'ptpsm' ) ; ?>
				</small>
			</span>
		</div>
	<?php

	}

	function ptpsm_respond() {

		if ( ( defined('DOING_AJAX') && DOING_AJAX ) === false ) {
			die( 'Error!' );
			exit;
		}

		if ( isset($_POST) && isset( $_POST['ptpsm_id'] ) ) {
			$curr_post_id = absint( stripslashes( $_POST['ptpsm_id'] ) );
			if ( get_post_status( $curr_post_id ) === false ) {
				die( 'Error!' );
				exit;
			}
		}
		else {
			die( 'Error!' );
			exit;
		}

		$curr_post_author = self::ptpsm_check_premissions( $curr_post_id );

		if ( $curr_post_author === false ) {
			die( 'Error!' );
			exit;
		}

		$product = wc_get_product( $curr_post_id );

		if ( $product->is_type( 'simple' ) ) {
			$product_type_class = ' ptpsm-simple-product';
			$product_information = __( 'Simple Product', 'ptpsm' ) . '<br/> #ID ' . $curr_post_id;
		}
		else if ( $product->is_type( 'variable' ) ) {
			$product_type_class = ' ptpsm-variable-product';
			$product_information = __( 'Variable Product', 'ptpsm' ) . '<br/> #ID ' . $curr_post_id;
		}
		else if ( $product->is_type( 'external' ) ) {
			$product_type_class = ' ptpsm-external-product';
			$product_information = __( 'External Product', 'ptpsm' ) . '<br/> #ID ' . $curr_post_id;
		}
		else if ( $product->is_type( 'grouped' ) ) {
			$product_type_class = ' ptpsm-grouped-product';
			$product_information = __( 'Grouped Product', 'ptpsm' ) . '<br/> #ID ' . $curr_post_id;
		}
		else {
			$product_type_class = ' ptpsm-' . $product->product_type() . '-product';
			$product_information = __( 'Product', 'ptpsm' ) . ' #ID ' . $curr_post_id;
		}

		ob_start();
	?>
		<div class="ptpsm-quick-editor">
			<div class="ptpsm-screen<?php echo $product_type_class; ?>">
				<div class="ptpsm-controls">
					<div class="ptpsm-about">
						<img width="49" height="28" src="<?php echo plugins_url( 'assets/images/about.png', __FILE__ ); ?>" />
						<em>ptpSM</em>
						<small><?php echo __( 'Editing', 'ptpsm' ) . ': ' . $product_information; ?></small>
					</div>
					<span class="ptpsm-expand"><i class="ptpsmico-expand"></i></span>
					<span class="ptpsm-contract"><i class="ptpsmico-contract"></i></span>
					<span class="ptpsm-side-edit"><i class="ptpsmico-edit"></i></span>
					<span class="ptpsm-side-save"><i class="ptpsmico-save"></i></span>
					<span class="ptpsm-side-discard"><i class="ptpsmico-discard"></i></span>
					<div class="ptpsm-clear"></div>
				</div>
				<span class="ptpsm-headline"><?php _e( 'Product Data', 'ptpsm' ); ?></span>
				<div class="ptpsm-group-general">
					<label for="ptpsm-featured-image" class="ptpsm-featured-image">
						<a href="#" class="ptpsm-featured-image-trigger">
						<?php
							if ( has_post_thumbnail( $curr_post_id ) ) {
								$curr_image = wp_get_attachment_image_src( $curr_image_id = get_post_thumbnail_id( $curr_post_id ), 'thumbnail' );
							?>
								<img width="64" height="64" src="<?php echo $curr_image[0]; ?>" />
							<?php
							}
							else {
								$curr_image_id = 0;
							?>
								<img width="64" height="64" src="<?php echo plugins_url( 'assets/images/placeholder.gif', __FILE__ ); ?>" />
						<?php
							}
						?>
						</a>
						<input id="ptpsm-featured-image" name="ptpsm-featured-image" class="ptpsm-collect-data" type="hidden" value="<?php echo $curr_image_id; ?>" />
					</label>
					<div class="ptpsm-featured-image-controls">
						<a href="#" class="ptpsm-editor-button ptpsm-change-image"><?php _e( 'Change Image', 'ptpsm' ); ?></a>
						<a href="#" class="ptpsm-editor-button ptpsm-remove-image"><?php _e( 'Discard Image', 'ptpsm' ); ?></a>
					</div>
					<div class="ptpsm-clear"></div>
					<label for="ptpsm-product-name">
						<span><?php _e( 'Product Name', 'ptpsm' ); ?></span>
						<input id="ptpsm-product-name" name="ptpsm-product-name" class="ptpsm-reset-this ptpsm-collect-data" type="text" value="<?php echo get_the_title($curr_post_id); ?>"/>
					</label>
				<?php
					if ( !$product->is_type( 'variable' ) && !$product->is_type( 'grouped' ) ) {
				?>
					<label for="ptpsm-regular-price" class="ptpsm-label-half ptpsm-label-first">
						<span><?php _e( 'Regular Price', 'ptpsm' ); ?></span>
						<input id="ptpsm-regular-price" name="ptpsm-regular-price" class="ptpsm-reset-this ptpsm-collect-data" type="text" value="<?php echo $product->get_regular_price(); ?>"/>
					</label>
					<label for="ptpsm-sale-price" class="ptpsm-label-half">
						<span><?php _e( 'Sale Price', 'ptpsm' ); ?></span>
						<input id="ptpsm-sale-price" name="ptpsm-sale-price" class="ptpsm-reset-this ptpsm-collect-data" type="text" value="<?php echo $product->get_sale_price(); ?>"/>
					</label>
					<div class="ptpsm-clear"></div>
				<?php
					}
					?>
				</div>
				<span class="ptpsm-headline ptpsm-headline-taxonomies"><?php _e( 'Product Taxnonomies and Terms', 'ptpsm' ); ?></span>
				<div class="ptpsm-group-taxonomies">
					<label for="ptpsm-select-product_cat" class="ptpsm-selectize">
						<span><?php _e( 'Product Categories', 'ptpsm' ); ?></span>
						<select id="ptpsm-select-product_cat" name="ptpsm-select-product_cat" class="ptpsm-collect-data" multiple="multiple">
						<?php
							$product_cats = wp_get_post_terms($curr_post_id, 'product_cat', array( 'fields' => 'slugs' ) );
							foreach( get_terms('product_cat','parent=0&hide_empty=0') as $term ) {
								$ptpsm_selected = in_array( $term->slug , $product_cats ) ? 'added' : 'notadded' ;
							?>
								<option <?php echo ( $ptpsm_selected == 'added' ? ' selected="selected"' : '' ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
							<?php
							}
						?>
						</select>
					</label>
				</div>
				<div class="ptpsm-clear"></div>
				<script type="text/javascript">
					(function($){
						"use strict";

						$(document).on('click', '.ptpsm-quick-editor label.ptpsm-featured-image > a.ptpsm-featured-image-trigger, .ptpsm-change-image', function () {

							if ( $(this).hasClass('ptpsm-change-image') ) {
								var el = $(this).parent().prev().find('.ptpsm-featured-image-trigger');
							}
							else {
								var el = $(this);
							}

							var curr = el.parent();

							if ( $.isEmptyObject(window.ptpsm_frame) == false ) {

								window.ptpsm_frame.off('select');

								window.ptpsm_frame.on( 'select', function() {

									var attachment = window.ptpsm_frame.state().get('selection').first();
									window.ptpsm_frame.close();

									curr.find('input:hidden').val(attachment.id);
									if ( attachment.attributes.type == 'image' ) {
										el.html('<img width="64" height="64" src="'+attachment.attributes.sizes.thumbnail.url+'" />');
									}

								});

								window.ptpsm_frame.open();

								return false;
							}


							window.ptpsm_frame = wp.media({
								title: '<?php echo esc_attr( __('Set Featured Image','ptpsm') ); ?>',
								button: {
									text: el.data("update"),
									close: false
								},
								multiple: false,
								default_tab: 'upload',
								tabs: 'upload, library',
								returned_image_size: 'thumbnail'
							});

							window.ptpsm_frame.off('select');

							window.ptpsm_frame.on( 'select', function() {

								var attachment = window.ptpsm_frame.state().get('selection').first();
								window.ptpsm_frame.close();

								curr.find('input:hidden').val(attachment.id);
								if ( attachment.attributes.type == 'image' ) {
									el.html('<img width="64" height="64" src="'+attachment.attributes.sizes.thumbnail.url+'" />');
								}

							});

							window.ptpsm_frame.open();

							return false;

						});

						$('.ptpsm-group-taxonomies .ptpsm-selectize select').each( function() {
							var curr = $(this);

							curr.selectize({
								plugins: ['remove_button'],
								delimiter: ',',
								persist: false,
								create: function(input) {
									return {
										value: input,
										text: input
									}
								}
							});
						});
					})(jQuery);
				</script>
				<small><?php echo 'pt Frontend Shop Manager<br/>Free Version 1.0.0<br/>by <a href="http://mihajlovicnenad.com">mihajlovicnenad.com</a><br/><a href="http://codecanyon.net/user/dzeriho/portfolio?ref=dzeriho">Get more premium plugins at this link!</a><br/><a href="http://codecanyon.net/item/pt-frontend-shop-manager/10694235?ref=dzeriho">Get pt Frontend Shop Manager <strong>Premium</strong> at this link!!</a>'; ?></small>
			</div>
		</div>
	<?php
		$out = ob_get_clean();

		die($out);
		exit;

	}

	function product_exist( $sku ) {
		global $wpdb;
		$product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value= %s LIMIT 1", $sku ) );
		return $product_id;
	}

	function ptpsm_save() {

		if ( ( defined('DOING_AJAX') && DOING_AJAX ) === false ) {
			die( 'Error!' );
			exit;
		}

		if ( isset($_POST) && isset( $_POST['ptpsm_id'] ) ) {
			$curr_post_id = absint( stripslashes( $_POST['ptpsm_id'] ) );
			if ( get_post_status( $curr_post_id ) === false ) {
				die( 'Error!' );
				exit;
			}
		}
		else {
			die( 'Error!' );
			exit;
		}

		$curr_post_author = self::ptpsm_check_premissions( $curr_post_id );

		if ( $curr_post_author === false ) {
			die( 'Error!' );
			exit;
		}

		$curr_data = array();
		$curr_data = json_decode( stripslashes( $_POST['ptpsm_save'] ), true );

		$curr_post = array(
			'ID' => $curr_post_id,
			'post_title' => $curr_data['ptpsm-product-name'],
		);

		wp_update_post( $curr_post );

		if ( isset($curr_data['ptpsm-featured-image']) ) {
			$curr_val = intval( stripslashes( $curr_data['ptpsm-featured-image'] ) );
			if ( wp_attachment_is_image( $curr_val ) ) {
				update_post_meta( $curr_post_id, '_thumbnail_id', $curr_val );
			}
		}

		if ( isset($curr_data['ptpsm-regular-price']) && $curr_data['ptpsm-regular-price'] !== '' ) {
			update_post_meta( $curr_post_id, '_regular_price', intval( $curr_data['ptpsm-regular-price'] ) );
			if ( intval( $curr_data['ptpsm-sale-price'] ) == '' ) {
				update_post_meta( $curr_post_id, '_price', intval( $curr_data['ptpsm-regular-price'] ) );
			}
		}
		else if ( isset($curr_data['ptpsm-regular-price']) && $curr_data['ptpsm-regular-price'] == '' ) {
			update_post_meta( $curr_post_id, '_regular_price', '' );
		}

		if ( isset($curr_data['ptpsm-sale-price']) && $curr_data['ptpsm-sale-price'] !== '' ) {
			update_post_meta( $curr_post_id, '_sale_price', intval( $curr_data['ptpsm-sale-price'] ) );
			update_post_meta( $curr_post_id, '_price', intval( $curr_data['ptpsm-sale-price'] ) );
		}
		else if ( isset($curr_data['ptpsm-sale-price']) && $curr_data['ptpsm-sale-price'] == '' ) {
			update_post_meta( $curr_post_id, '_sale_price', '' );
		}

		if ( isset($curr_data['ptpsm-select-product_cat']) && $curr_data['ptpsm-select-product_cat'] !== null && is_array( $curr_data['ptpsm-select-product_cat'] ) ) {

			$add_terms = array();
			$ready_array = array_map( 'sanitize_text_field', $curr_data['ptpsm-select-product_cat'] );

			foreach ( $ready_array as $curr_tax ) {
				$curr_slug = sanitize_title( $curr_tax );
				if ( !get_term_by( 'slug', $curr_slug, 'product_cat' ) ) {
					wp_insert_term( $curr_tax, 'product_cat', array( 'slug' => $curr_tax ) );
				}
				$add_terms[] = $curr_slug;
			}
			wp_set_object_terms( $curr_post_id, $add_terms, 'product_cat' );

		}
		else {
			wp_set_object_terms( $curr_post_id, array(), 'product_cat' );
		}


		$curr_loop = isset( $_POST['ptpsm_loop'] ) ? sanitize_text_field( $_POST['ptpsm_loop'] ) : 'single';

		if ( $curr_loop !== 'single' ) {

			$ptpsm_settings = strpos( $curr_loop, '|' ) ? explode( '|', $curr_loop ) : 'single';
			
			if ( is_array( $ptpsm_settings ) ) {

				global $pt_loop;

				$pt_loop = array(
					'loop' => intval( $ptpsm_settings[0] ) - 1,
					'columns' => intval( $ptpsm_settings[1] )
				);

				$curr_products = new WP_Query( array( 'post_type' => 'product', 'post__in' => array( $curr_post_id ) ) );

				ob_start();

				if ( $curr_products->have_posts() ) {

					while ( $curr_products->have_posts() ) : $curr_products->the_post();

						wc_get_template_part( 'content', 'product' );

					endwhile;

				}

				$out = ob_get_clean();

			}
			else {
				$out = 'single';
			}
		}
		else {
			$out = 'single';
		}

		die($out);
		exit;
	}

	public static function ptpsm_check_premissions( $curr_post_id ) {

		$curr_post_author = absint( get_post_field( 'post_author', $curr_post_id ) );

		$curr_logged_user = get_current_user_id();

		$curr_user = get_user_by( 'id', $curr_logged_user );

		if ( $curr_user->has_cap( 'administrator' ) || $curr_user->has_cap( 'manage_pt' ) ) {
			$curr_admin = true;
		}

		if ( !isset( $curr_admin ) && absint( $curr_post_author ) !== $curr_logged_user ) {
			return false;
		}
		else {
			return $curr_post_author;
		}

	}

}

?>