(function($){

	"use strict";

	window.wfsm_frame = {};
	window.wfsm_frame_gallery = {};

})(jQuery);